Hey! Thank you for downloading this texture pack! This took me a while to create,
so your support helps me keep my motivation to work on this! If you feel like something
needs to be tweaked, feel free to post a comment on the texture pack's Tubble post!

Little reminder, this texture pack requires a mod on fabric called "Server Pack Unlocker" to use!

LINKS:
SPU Mod: https://modrinth.com/mod/server-pack-unlocker
Christmas Tubnet Tweaks: https://modrinth.com/resourcepack/christmas-tubnet-tweaks
Tubnet Tweaks Tubble Post: forums.tubnet.gg/threads/6410
