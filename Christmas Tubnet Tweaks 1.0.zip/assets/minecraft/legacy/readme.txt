items in this folder are here because I spent a lot of time making them
only to have them break/not work when I tried it in-game.

Go ahead and do whatever you want with them!